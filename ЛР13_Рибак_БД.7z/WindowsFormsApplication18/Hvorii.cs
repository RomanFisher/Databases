﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication18
{
    class Hvorii
    {
        public int id;
        public String fname;
        public String name;
        public String pname;
       /* public String nzhal;
        public DateTime date;*/
    }
}
